# Decision Tree

 * bucheim.py - implementation of "Drawing rooted trees in linear time(Buchheim, Junger and Leipert, 2006)"
 * id3_decision_tree.py - Our own heuristic id3 decision tree algorithm
 * generate_bokeh_data.py - Generate data source for bokeh
