# Data Sets
## Lenses:
Link: https://archive.ics.uci.edu/ml/datasets/lenses


## Mushrooms:
Link: https://archive.ics.uci.edu/ml/datasets/mushroom
