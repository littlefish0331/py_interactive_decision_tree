# Bokeh Operations

* instance.py - Singleton class for data set
* get_data.py - Parse source, pass to tree files, get to plot data
* plot_decision_tree.py- Plotting operations
